# Data used in English reverse dictionary.

Data on [Google Drive](https://drive.google.com/open?id=1ihfElRULa6bg_jpwzeHSJEC2KQc_w25p).
